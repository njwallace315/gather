module.exports = {
  development: {
    port: 4001,
  },
  test: {
    port: 8001,
  },
};
